<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    //    // Table name
        //protected $table = 'posts';//can rename table
        // Primary key
        //public $primaryKey = 'id';//rename id
        // Timestamps
    //public $timestamps = true;//put false if you don't want timestamps

    /*public function user(){
      return $this->belongsTo('App\user');
    }*/
}
